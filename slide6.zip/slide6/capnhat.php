<?php
// Kết nối với cơ sở dữ liệu
$conn = new mysqli('localhost', 'username', 'password', 'DSSP');

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Câu lệnh cập nhật dữ liệu
$sql = "UPDATE SANPHAM SET price=1700000, quantily=50 WHERE pro_id=1";

if ($conn->query($sql) === TRUE) {
    echo "Dữ liệu đã được cập nhật thành công";
} else {
    echo "Lỗi: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
