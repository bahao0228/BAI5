-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost
-- Thời gian đã tạo: Th9 13, 2024 lúc 05:49 PM
-- Phiên bản máy phục vụ: 10.4.28-MariaDB
-- Phiên bản PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `DSSP`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `SANPHAM`
--

CREATE TABLE `SANPHAM` (
  `pro_id` int(5) NOT NULL,
  `pro_name` varchar(255) NOT NULL,
  `image` char(50) NOT NULL,
  `price` int(10) NOT NULL,
  `quantily` int(10) NOT NULL,
  `description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `SANPHAM`
--

INSERT INTO `SANPHAM` (`pro_id`, `pro_name`, `image`, `price`, `quantily`, `description`) VALUES
(1, 'CRAZYFAST MESSI.3 TF', 'CRAZYFAST MESSI.3 TF.jpg', 2400000, 45, 'Xanh đen'),
(2, 'CRAZYFAST ELITE TF', 'CRAZYFAST ELITE TF.jpg', 1200000, 5, 'Cảm đỏ'),
(3, 'SUPERFLY 9 ACADEMT TF', 'SUPERFLY 9 ACADEMY TF.jpeg', 2000000, 23, 'Màu trắng kem sữa'),
(4, 'CRAZYFAST MESSI.3 TF', 'SPEEDPORTAL.1 TF.jpg', 1000000, 5, 'Xám xanh'),
(5, 'NIKE REACT PHANTOM GX PRO TF1', 'NIKE REACT PHANTOM GX PRO TF.jpg', 2100000, 24, 'Đỏ đen, dành cho sân nhân tạo'),
(6, 'NIKE ZOOM MERCURIAL SUPERFLY 9 ACADEMY MDS TF', 'NIKE ZOOM MERCURIAL SUPERFLY 9 ACADEMY MDS TF.jpg', 1700000, 20, 'Xanh, Dành cho sân cỏ nhân tạo'),
(7, 'SPEEDPORTAL.3 FG', 'SPEEDPORTAL.3 FG.jpeg', 2500000, 10, 'Xanh cây, dành cho sân cỏ tự nhiên'),
(8, 'SUPERFLY 9 ACADEMY', 'ADIDAS X CRAZYFAST.3 TF.jpg', 1000000, 24, 'Màu trắng kem sữa'),
(9, 'CRAZYFAST.3 TF', 'FJ7199-300.jpg', 120000, 12, 'Thương hiệu: nike'),
(10, 'Men Multi-Ground Soccer Cleats', 'Men Multi-Ground Soccer Cleats.jpeg', 3100000, 5, 'Dành cho sân cỏ tự nhiên, hãng Nike, màu trắng xanh nhạt');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `SANPHAM`
--
ALTER TABLE `SANPHAM`
  ADD PRIMARY KEY (`pro_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `SANPHAM`
--
ALTER TABLE `SANPHAM`
  MODIFY `pro_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
