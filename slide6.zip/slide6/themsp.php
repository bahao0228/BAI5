<?php
// Kết nối với cơ sở dữ liệu
$conn = new mysqli('localhost', 'username', 'password', 'DSSP');

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Câu lệnh thêm dữ liệu
$sql = "INSERT INTO SANPHAM (pro_name, image, price, quantily, description) 
        VALUES ('New Product', 'new_image.jpg', 1500000, 30, 'New description')";

if ($conn->query($sql) === TRUE) {
    echo "Dữ liệu đã được thêm thành công";
} else {
    echo "Lỗi: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
