<?php
$host = 'localhost';  // Địa chỉ máy chủ MySQL
$db   = 'DSSP';       // Tên cơ sở dữ liệu
$user = 'root';       // Tên người dùng MySQL
$pass = '';           // Mật khẩu MySQL (để trống nếu không có mật khẩu)
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,  // Bật chế độ thông báo lỗi
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,        // Mặc định là FETCH_ASSOC
    PDO::ATTR_EMULATE_PREPARES   => false,                   // Vô hiệu hóa giả lập prepare statements
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    echo "Kết nối thành công!";
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}
?>
