<?php
// Chuẩn bị câu lệnh SQL để lấy dữ liệu
$sql = "SELECT pro_id, pro_name, price, quantily, description FROM SANPHAM";

// Chuẩn bị và thực hiện câu lệnh
$stmt = $pdo->query($sql);

// Lặp qua các kết quả và hiển thị
while ($row = $stmt->fetch()) {
    echo "ID: " . $row['pro_id'] . "<br>";
    echo "Tên sản phẩm: " . $row['pro_name'] . "<br>";
    echo "Giá: " . $row['price'] . "<br>";
    echo "Số lượng: " . $row['quantily'] . "<br>";
    echo "Mô tả: " . $row['description'] . "<br><br>";
}
?>
