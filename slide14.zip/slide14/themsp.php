<?php
// Chuẩn bị câu lệnh SQL để thêm sản phẩm mới
$sql = "INSERT INTO SANPHAM (pro_name, image, price, quantily, description) 
        VALUES (:pro_name, :image, :price, :quantily, :description)";

// Chuẩn bị và thực hiện câu lệnh
$stmt = $pdo->prepare($sql);

// Dữ liệu bất kỳ
$pro_name = 'Nike Phantom GT2 Academy'; 
$image = 'nike_phantom_gt2.jpg';
$price = 2000000;
$quantily = 30;
$description = 'Sản phẩm mới nhất của Nike cho sân cỏ tự nhiên.';

// Gán các tham số
$stmt->execute(['pro_name' => $pro_name, 'image' => $image, 'price' => $price, 'quantily' => $quantily, 'description' => $description]);

echo "Thêm sản phẩm thành công!";
?>
