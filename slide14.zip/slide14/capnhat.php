<?php
// Chuẩn bị câu lệnh SQL để cập nhật sản phẩm
$sql = "UPDATE SANPHAM SET price = :price, quantily = :quantily WHERE pro_id = :pro_id";

// Chuẩn bị và thực hiện câu lệnh
$stmt = $pdo->prepare($sql);

// Dữ liệu bất kỳ
$pro_id = 1; // Cập nhật sản phẩm có ID là 1
$price = 2500000; // Giá mới
$quantily = 50; // Số lượng mới

// Gán các tham số
$stmt->execute(['price' => $price, 'quantily' => $quantily, 'pro_id' => $pro_id]);

echo "Cập nhật sản phẩm thành công!";
?>
