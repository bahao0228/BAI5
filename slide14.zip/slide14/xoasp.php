<?php
// Chuẩn bị câu lệnh SQL để xóa sản phẩm
$sql = "DELETE FROM SANPHAM WHERE pro_id = :pro_id";

// Chuẩn bị và thực hiện câu lệnh
$stmt = $pdo->prepare($sql);

// Dữ liệu bất kỳ
$pro_id = 2; // Xóa sản phẩm có ID là 2

// Gán tham số và thực thi
$stmt->execute(['pro_id' => $pro_id]);

echo "Xóa sản phẩm thành công!";
?>
